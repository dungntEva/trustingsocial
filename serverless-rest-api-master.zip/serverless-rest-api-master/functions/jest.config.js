module.exports = {
  "roots": [
    "<rootDir>/__tests__",
    "<rootDir>/test"
  ],
  "transform": {
    "^.+\\.tsx?$": "ts-jest"
  },
}
